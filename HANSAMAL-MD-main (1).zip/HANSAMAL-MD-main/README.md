<br>
 </p>
    <p align="center">
    WAIT NEXT UPDATE FIX ALL ERORRS.......   
<br>
 </p>
    <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=WELCOME+TO+HANSAMAL-MD;MULTI-DEVICE+WHATSAPP+BOT;DEVELOPED+BY;IMALKA-HANSAMAL." alt="Typing SVG" /></a>

 
  
<div align="center">
</p

<hr>

<hr>

<p align="center">
  <a href="https://youtu.be/WcA7GZuaN0A">
    <img alt="HANSAMAL-MD" height="300" src="https://files.catbox.moe/4y72vl.jpg">

    

![forks](https://img.shields.io/github/forks/cobrs11/HANSAMAL-MD?label=Forks&style=social)

![stars](https://img.shields.io/github/stars/cobrs11/HANSAMAL-MD?style=social)




<a href="https://www.whatsapp.com/channel/0029VajrLTH30LKXN5O5Zj04"><img src="https://img.shields.io/badge/%E2%9D%A4%EF%B8%8F%E2%80%8D%20Join%20Our%20WhatsApp%20Channel%F0%9F%91%A8%E2%80%8D%F0%9F%92%BB-green" alt="📎 Join Our WhatsApp Channel" width="300"></a>



## MY YT CHANNEL

[![Youtube](https://telegra.ph/file/eebe86c26e98ffeae39ea.jpg)](https://youtube.com/@IMALKAHANSAMAL) 

</details>





<hr>

<hr>
1. FORK THIS REPO


<a href='https://github.com/cobrs11/HANSAMAL-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>


<a href="https://cautious-halibut-pjgjrvgv5wxrhrxqw-8000.app.github.dev/" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

2. ## DEPLOY BY SESSION ID (WHATSAPP LOG WITH PAIR CODE)

<a href='https://replit.com/@atayafuataya/HANSAMAL-MD-1' target="_blank"><img alt='Get Session ID' src='https://img.shields.io/badge/%F0%9F%9A%80%EF%B8%8F%E2%80%8D%201-OUR%F0%9F%93%8B%20%20PAIR%20CODE%20WEB%F0%9F%91%A8%E2%80%8D%F0%9F%92%BB-yellow' width="400" height="50" alt="Deploy bot"/></a>

<hr>
<a href='https://replit.com/@atayafuataya/HANSAMAL-MD-1' target="_blank"><img alt='Session ID WEB' src='https://img.shields.io/badge/%F0%9F%9A%80%EF%B8%8F%E2%80%8D%202-OUR%F0%9F%93%8B%20%20PAIR%20CODE%20WEB%F0%9F%91%A8%E2%80%8D%F0%9F%92%BB-RED' width="400" height="50" alt="Deploy bot"/></a>

<hr>
<hr>

## DEPLOYMENT METHODS
3. ## Deploy to Koyeb ↓

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=hansamal-md&type=git&repository=cobrs11%2FHANSAMAL-MD&branch=main&builder=dockerfile&env%5BSESSION_ID%5D=your+sessionid+here&env%5BMODE%5D=public&env%5BAUTO_STATUS_SEEN%5D=true&env%5BAUTO_READ%5D=flase&env%5BAUTO_REACT%5D=flase&env%5BALWAYS_ONLINE%5D=flase&ports=8000%3Bhttp%3B%2F)

4. ## Deploy to RENDER ↓

<a href="https://dashboard.render.com/" target="blank"><img align="center" src="https://telegra.ph/file/c15e952f017c10e12f431.jpg" width="100" height="20" alt="Deploy bot"/></a>



   <a href="https://github.com/cobrs11/"><img src="https://telegra.ph/file/c718b67d351c1190e285b.jpg" width=80 height=80></a>   

|**[`IMALKA-HANSAMAL`](https://github.com/cobrs11)**|

## 👑 `HANSAMAL-MD BOT OWNER`👨‍💻 

 <br>
 </p>
    <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=THANKS+ALL+USE+MY+BOT;HANSAMAL-MD" alt="Typing SVG" /></a>
---
